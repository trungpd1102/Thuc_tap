﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO.Ports;

namespace Demo
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}


        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ComList = SerialPort.GetPortNames();
            //Array.Sort(ComList);
            int[] ComNumberList = new int[ComList.Length];
            for (int i = 0; i < ComList.Length; i++)
            {
                ComNumberList[i] = int.Parse(ComList[i].Substring(3));
            }

            Array.Sort(ComNumberList);

            foreach (int ComNumber in ComNumberList)
            {
                cbxComList.Items.Add("COM" + ComNumber.ToString());
            }
            //cbxComList.Items.AddRange(ComList);
        }

        private void buttKetnoi_Click(object sender, EventArgs e)
        {
            if (cbxComList.Text == "")
            {
                MessageBox.Show("Vui lòng chọn cổng COM","Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            

            if (serialPort.IsOpen)
            {
                serialPort.Close();
                buttKetnoi.Text = "Kết nối";
                cbxComList.Enabled = true;
                gbxDevice.Enabled = false;
            }
            else 
            {
                try
                {
                    serialPort.PortName = cbxComList.Text;
                    serialPort.Open();
                    buttKetnoi.Text = "Ngắt kết nối";
                    cbxComList.Enabled = false;
                    gbxDevice.Enabled = true;
                }
                catch
                {
                    MessageBox.Show("Không thể mở cổng" + serialPort.PortName, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
