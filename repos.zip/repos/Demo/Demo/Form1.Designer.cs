﻿namespace Demo
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttKetnoi = new System.Windows.Forms.Button();
            this.cbxComList = new System.Windows.Forms.ComboBox();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.gbxDevice = new System.Windows.Forms.GroupBox();
            this.chxDevice8 = new System.Windows.Forms.CheckBox();
            this.chxDevice7 = new System.Windows.Forms.CheckBox();
            this.chxDevice6 = new System.Windows.Forms.CheckBox();
            this.chxDevice5 = new System.Windows.Forms.CheckBox();
            this.chxDevice4 = new System.Windows.Forms.CheckBox();
            this.chxDevice3 = new System.Windows.Forms.CheckBox();
            this.chxDevice2 = new System.Windows.Forms.CheckBox();
            this.chxDevice1 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.gbxDevice.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttKetnoi);
            this.groupBox1.Controls.Add(this.cbxComList);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 82);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cài đặt cổng COM";
            // 
            // buttKetnoi
            // 
            this.buttKetnoi.Location = new System.Drawing.Point(147, 34);
            this.buttKetnoi.Name = "buttKetnoi";
            this.buttKetnoi.Size = new System.Drawing.Size(75, 23);
            this.buttKetnoi.TabIndex = 1;
            this.buttKetnoi.Text = "Kết nối";
            this.buttKetnoi.UseVisualStyleBackColor = true;
            this.buttKetnoi.Click += new System.EventHandler(this.buttKetnoi_Click);
            // 
            // cbxComList
            // 
            this.cbxComList.FormattingEnabled = true;
            this.cbxComList.Location = new System.Drawing.Point(6, 36);
            this.cbxComList.Name = "cbxComList";
            this.cbxComList.Size = new System.Drawing.Size(121, 21);
            this.cbxComList.TabIndex = 0;
            // 
            // gbxDevice
            // 
            this.gbxDevice.Controls.Add(this.chxDevice8);
            this.gbxDevice.Controls.Add(this.chxDevice7);
            this.gbxDevice.Controls.Add(this.chxDevice6);
            this.gbxDevice.Controls.Add(this.chxDevice5);
            this.gbxDevice.Controls.Add(this.chxDevice4);
            this.gbxDevice.Controls.Add(this.chxDevice3);
            this.gbxDevice.Controls.Add(this.chxDevice2);
            this.gbxDevice.Controls.Add(this.chxDevice1);
            this.gbxDevice.Enabled = false;
            this.gbxDevice.Location = new System.Drawing.Point(12, 100);
            this.gbxDevice.Name = "gbxDevice";
            this.gbxDevice.Size = new System.Drawing.Size(203, 304);
            this.gbxDevice.TabIndex = 1;
            this.gbxDevice.TabStop = false;
            this.gbxDevice.Text = "Các thiết bị";
            // 
            // chxDevice8
            // 
            this.chxDevice8.AutoSize = true;
            this.chxDevice8.Location = new System.Drawing.Point(17, 264);
            this.chxDevice8.Name = "chxDevice8";
            this.chxDevice8.Size = new System.Drawing.Size(70, 17);
            this.chxDevice8.TabIndex = 0;
            this.chxDevice8.Text = "Thiết bị 8";
            this.chxDevice8.UseVisualStyleBackColor = true;
            // 
            // chxDevice7
            // 
            this.chxDevice7.AutoSize = true;
            this.chxDevice7.Location = new System.Drawing.Point(17, 224);
            this.chxDevice7.Name = "chxDevice7";
            this.chxDevice7.Size = new System.Drawing.Size(70, 17);
            this.chxDevice7.TabIndex = 0;
            this.chxDevice7.Text = "Thiết bị 7";
            this.chxDevice7.UseVisualStyleBackColor = true;
            // 
            // chxDevice6
            // 
            this.chxDevice6.AutoSize = true;
            this.chxDevice6.Location = new System.Drawing.Point(17, 187);
            this.chxDevice6.Name = "chxDevice6";
            this.chxDevice6.Size = new System.Drawing.Size(70, 17);
            this.chxDevice6.TabIndex = 0;
            this.chxDevice6.Text = "Thiết bị 6";
            this.chxDevice6.UseVisualStyleBackColor = true;
            // 
            // chxDevice5
            // 
            this.chxDevice5.AutoSize = true;
            this.chxDevice5.Location = new System.Drawing.Point(17, 153);
            this.chxDevice5.Name = "chxDevice5";
            this.chxDevice5.Size = new System.Drawing.Size(70, 17);
            this.chxDevice5.TabIndex = 0;
            this.chxDevice5.Text = "Thiết bị 5";
            this.chxDevice5.UseVisualStyleBackColor = true;
            // 
            // chxDevice4
            // 
            this.chxDevice4.AutoSize = true;
            this.chxDevice4.Location = new System.Drawing.Point(17, 116);
            this.chxDevice4.Name = "chxDevice4";
            this.chxDevice4.Size = new System.Drawing.Size(70, 17);
            this.chxDevice4.TabIndex = 0;
            this.chxDevice4.Text = "Thiết bị 4";
            this.chxDevice4.UseVisualStyleBackColor = true;
            // 
            // chxDevice3
            // 
            this.chxDevice3.AutoSize = true;
            this.chxDevice3.Location = new System.Drawing.Point(17, 84);
            this.chxDevice3.Name = "chxDevice3";
            this.chxDevice3.Size = new System.Drawing.Size(70, 17);
            this.chxDevice3.TabIndex = 0;
            this.chxDevice3.Text = "Thiết bị 3";
            this.chxDevice3.UseVisualStyleBackColor = true;
            // 
            // chxDevice2
            // 
            this.chxDevice2.AutoSize = true;
            this.chxDevice2.Location = new System.Drawing.Point(17, 51);
            this.chxDevice2.Name = "chxDevice2";
            this.chxDevice2.Size = new System.Drawing.Size(70, 17);
            this.chxDevice2.TabIndex = 0;
            this.chxDevice2.Text = "Thiết bị 2";
            this.chxDevice2.UseVisualStyleBackColor = true;
            // 
            // chxDevice1
            // 
            this.chxDevice1.AutoSize = true;
            this.chxDevice1.Location = new System.Drawing.Point(17, 19);
            this.chxDevice1.Name = "chxDevice1";
            this.chxDevice1.Size = new System.Drawing.Size(70, 17);
            this.chxDevice1.TabIndex = 0;
            this.chxDevice1.Text = "Thiết bị 1";
            this.chxDevice1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 450);
            this.Controls.Add(this.gbxDevice);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.gbxDevice.ResumeLayout(false);
            this.gbxDevice.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox cbxComList;
		private System.IO.Ports.SerialPort serialPort;
		private System.Windows.Forms.GroupBox gbxDevice;
		private System.Windows.Forms.CheckBox chxDevice8;
		private System.Windows.Forms.CheckBox chxDevice7;
		private System.Windows.Forms.CheckBox chxDevice6;
		private System.Windows.Forms.CheckBox chxDevice5;
		private System.Windows.Forms.CheckBox chxDevice4;
		private System.Windows.Forms.CheckBox chxDevice3;
		private System.Windows.Forms.CheckBox chxDevice2;
		private System.Windows.Forms.CheckBox chxDevice1;
		private System.Windows.Forms.Button buttKetnoi;
	}
}

